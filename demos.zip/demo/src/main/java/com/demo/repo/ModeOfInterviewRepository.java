package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.entity.ModeOfInterview;

@Repository
public interface ModeOfInterviewRepository extends JpaRepository<ModeOfInterview,Long> {

	ModeOfInterview save(ModeOfInterview mode);
	
}
