package com.demo.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class EmployeeDetails {


	@Id
	@GeneratedValue
	private int id;
	private String candidateName;
	private String interName;
	
	
//	@OneToMany
////	(cascade=CascadeType.ALL, mappedBy="skillId",targetEntity=Skill.class)
//	@JoinTable(name = "skills", joinColumns = @JoinColumn(name = "id"), inverseJoinColumns = @JoinColumn(name = "skillId"))
//	private List<Skill> skills;
//
//	public List<Skill> getSkills() {
//		return skills;
//	}
//
//	public void setSkills(List<Skill> skills) {
//		this.skills = skills;
//	}
//
	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getInterName() {
		return interName;
	}

	public void setInterName(String interName) {
		this.interName = interName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", candidateName=" + candidateName + ", interName=" + interName + "]";
	}

}
