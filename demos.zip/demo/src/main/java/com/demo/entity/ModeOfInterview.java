package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mode_of_iterview" )
public class ModeOfInterview {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name = "serial")
	private Long id;
	private String value;
	private boolean interviewLocation;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public boolean isInterviewLocation() {
		return interviewLocation;
	}
	public void setInterviewLocation(boolean interviewLocation) {
		this.interviewLocation = interviewLocation;
	}
	public ModeOfInterview(Long id, String value, boolean interviewLocation) {
		super();
		this.id = id;
		this.value = value;
		this.interviewLocation = interviewLocation;
	}
	public ModeOfInterview() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (interviewLocation ? 1231 : 1237);
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ModeOfInterview other = (ModeOfInterview) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (interviewLocation != other.interviewLocation)
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ModeOfInerview [id=" + id + ", value=" + value + ", interviewLocation=" + interviewLocation + "]";
	}
	
	

	
	
}
