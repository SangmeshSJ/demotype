package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "interview_panel")
 public class InterviewPanel {
  
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name = "serial")
	
  private Long id;
  private String name;
  private String level;
  private String employee;
  private String signature;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLevel() {
	return level;
}
public void setLevel(String level) {
	this.level = level;
}
public String getEmployee() {
	return employee;
}
public void setEmployee(String employee) {
	this.employee = employee;
}
public String getSignature() {
	return signature;
}
public void setSignature(String signature) {
	this.signature = signature;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((employee == null) ? 0 : employee.hashCode());
	result = prime * result + ((id == null) ? 0 : id.hashCode());
	result = prime * result + ((level == null) ? 0 : level.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + ((signature == null) ? 0 : signature.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	InterviewPanel other = (InterviewPanel) obj;
	if (employee == null) {
		if (other.employee != null)
			return false;
	} else if (!employee.equals(other.employee))
		return false;
	if (id == null) {
		if (other.id != null)
			return false;
	} else if (!id.equals(other.id))
		return false;
	if (level == null) {
		if (other.level != null)
			return false;
	} else if (!level.equals(other.level))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	if (signature == null) {
		if (other.signature != null)
			return false;
	} else if (!signature.equals(other.signature))
		return false;
	return true;
}
@Override
public String toString() {
	return "InterviewPanel [id=" + id + ", name=" + name + ", level=" + level + ", employee=" + employee
			+ ", signature=" + signature + "]";
}
public InterviewPanel(Long id, String name, String level, String employee, String signature) {
	super();
	this.id = id;
	this.name = name;
	this.level = level;
	this.employee = employee;
	this.signature = signature;
}
public InterviewPanel() {
	super();
	// TODO Auto-generated constructor stub
}
  
	
}
