package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "candidate_detail")
public class CandidateDetail {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(columnDefinition = "serial")
	private Long Id;
	private String candidateName;
	private String date;
	private String skills;
	private String bu;
	private String totalYearsOfExp;
	private String relevantYearsOfExp;
	private String candidateSeemsStrongIn;
	private String candidateRequiresTrainingOn;
	private String others;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getTotalYearsOfExp() {
		return totalYearsOfExp;
	}
	public void setTotalYearsOfExp(String totalYearsOfExp) {
		this.totalYearsOfExp = totalYearsOfExp;
	}
	public String getRelevantYearsOfExp() {
		return relevantYearsOfExp;
	}
	public void setRelevantYearsOfExp(String relevantYearsOfExp) {
		this.relevantYearsOfExp = relevantYearsOfExp;
	}
	
	public String getCandidateSeemsStrongIn() {
		return candidateSeemsStrongIn;
	}
	public void setCandidateSeemsStrongIn(String candidateSeemsStrongIn) {
		this.candidateSeemsStrongIn = candidateSeemsStrongIn;
	}
	public String getCandidateRequiresTrainingOn() {
		return candidateRequiresTrainingOn;
	}
	public void setCandidateRequiresTrainingOn(String candidateRequiresTrainingOn) {
		this.candidateRequiresTrainingOn = candidateRequiresTrainingOn;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	
	public CandidateDetail() {
		
	}
	public CandidateDetail(Long id, String candidateName, String date, String skills, String bu, String totalYearsOfExp,
			String relevantYearsOfExp, String candidateSeemsStrongIn, String candidateRequiresTrainingOn,
			String others) {
		super();
		Id = id;
		this.candidateName = candidateName;
		this.date = date;
		this.skills = skills;
		this.bu = bu;
		this.totalYearsOfExp = totalYearsOfExp;
		this.relevantYearsOfExp = relevantYearsOfExp;
		this.candidateSeemsStrongIn = candidateSeemsStrongIn;
		this.candidateRequiresTrainingOn = candidateRequiresTrainingOn;
		this.others = others;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Id == null) ? 0 : Id.hashCode());
		result = prime * result + ((bu == null) ? 0 : bu.hashCode());
		result = prime * result + ((candidateName == null) ? 0 : candidateName.hashCode());
		result = prime * result + ((candidateRequiresTrainingOn == null) ? 0 : candidateRequiresTrainingOn.hashCode());
		result = prime * result + ((candidateSeemsStrongIn == null) ? 0 : candidateSeemsStrongIn.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((others == null) ? 0 : others.hashCode());
		result = prime * result + ((relevantYearsOfExp == null) ? 0 : relevantYearsOfExp.hashCode());
		result = prime * result + ((skills == null) ? 0 : skills.hashCode());
		result = prime * result + ((totalYearsOfExp == null) ? 0 : totalYearsOfExp.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CandidateDetail other = (CandidateDetail) obj;
		if (Id == null) {
			if (other.Id != null)
				return false;
		} else if (!Id.equals(other.Id))
			return false;
		if (bu == null) {
			if (other.bu != null)
				return false;
		} else if (!bu.equals(other.bu))
			return false;
		if (candidateName == null) {
			if (other.candidateName != null)
				return false;
		} else if (!candidateName.equals(other.candidateName))
			return false;
		if (candidateRequiresTrainingOn == null) {
			if (other.candidateRequiresTrainingOn != null)
				return false;
		} else if (!candidateRequiresTrainingOn.equals(other.candidateRequiresTrainingOn))
			return false;
		if (candidateSeemsStrongIn == null) {
			if (other.candidateSeemsStrongIn != null)
				return false;
		} else if (!candidateSeemsStrongIn.equals(other.candidateSeemsStrongIn))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (others == null) {
			if (other.others != null)
				return false;
		} else if (!others.equals(other.others))
			return false;
		if (relevantYearsOfExp == null) {
			if (other.relevantYearsOfExp != null)
				return false;
		} else if (!relevantYearsOfExp.equals(other.relevantYearsOfExp))
			return false;
		if (skills == null) {
			if (other.skills != null)
				return false;
		} else if (!skills.equals(other.skills))
			return false;
		if (totalYearsOfExp == null) {
			if (other.totalYearsOfExp != null)
				return false;
		} else if (!totalYearsOfExp.equals(other.totalYearsOfExp))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "CandidateDetail [Id=" + Id + ", candidateName=" + candidateName + ", date=" + date + ", skills="
				+ skills + ", bu=" + bu + ", totalYearsOfExp=" + totalYearsOfExp + ", relevantYearsOfExp="
				+ relevantYearsOfExp + ", candidateSeemsStrongIn=" + candidateSeemsStrongIn
				+ ", candidateRequiresTrainingOn=" + candidateRequiresTrainingOn + ", others=" + others + "]";
	}

	
	
	
	
	
	
}
