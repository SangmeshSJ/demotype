package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.CandidateDetail;
import com.demo.entity.InterviewPanel;
import com.demo.entity.ModeOfInterview;
import com.demo.entity.Skill;
import com.demo.entity.SkillSet;
import com.demo.repo.CandidateRepository;
import com.demo.repo.InterviewPanelRepository;
import com.demo.repo.ModeOfInterviewRepository;
import com.demo.repo.SkillRepository;
import com.demo.repo.SkillSetRepository;

@Controller
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/candidate")
public class CandidateController {

	 @Autowired
	 SkillRepository skillrepository;
	 @Autowired
	 SkillSetRepository _skill;
	 @Autowired
     CandidateRepository _candidate;
     @Autowired
     InterviewPanelRepository _interview;
     @Autowired
     ModeOfInterviewRepository _mode;
	@PostMapping("/skills")
	  public Skill skill(@RequestBody Skill skill) {
		Skill _employee = skillrepository.save(skill);
	    return _employee;
	  }
	
	@PostMapping("/candidateDetails")
	  public CandidateDetail candidate(@RequestBody CandidateDetail employee) {
		CandidateDetail candidate = _candidate.save(employee);
	    return candidate;
	  }
	
	@PostMapping("/skillsets")
	public SkillSet skill(@RequestBody SkillSet set)
	{
		SkillSet skill =  _skill.save(set);
		return skill;
	}
	
	@PostMapping("/interviewPanel")
	public InterviewPanel interview(@RequestBody InterviewPanel interview) 
	{
		InterviewPanel interview1 = _interview.save(interview);
		return interview1;
	}
	@PostMapping("/modeofinterview")
	public ModeOfInterview mode(@RequestBody ModeOfInterview mode)
	{
		ModeOfInterview modeq = _mode.save(mode);
		return modeq;
	}
}
